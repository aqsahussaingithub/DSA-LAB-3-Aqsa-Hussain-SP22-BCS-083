#include <iostream>
using namespace std;

int main() {
    // Program 1: Basic Pointer
    int x = 10;
    int* ptr = &x;
    cout << "Program 1: Basic Pointer" << endl;
    cout << "Value of x: " << x << endl;
    cout << "Value pointed to by ptr: " << *ptr << endl;
return 0;}
