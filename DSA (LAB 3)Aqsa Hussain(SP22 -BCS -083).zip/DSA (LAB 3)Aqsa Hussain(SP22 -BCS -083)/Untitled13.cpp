#include <iostream>
void modifyValue(int *ptr) {
    (*ptr)++;
}
int main() {
    int num = 42;
    modifyValue(&num);
    std::cout << "Modified Value: " << num << std::endl;
    return 0;
}
