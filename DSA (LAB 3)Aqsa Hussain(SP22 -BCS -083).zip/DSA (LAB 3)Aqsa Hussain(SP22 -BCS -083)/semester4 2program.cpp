#include <iostream>
using namespace std;

int main() {
int arr[] = {1, 2, 3, 4, 5};
    int* p = arr;
    cout << "\nProgram 2: Pointer Arithmetic" << endl;
    cout << "Value at p: " << *p << endl;
    p++;
    cout << "Value at p++: " << *p << endl;
return 0;}
