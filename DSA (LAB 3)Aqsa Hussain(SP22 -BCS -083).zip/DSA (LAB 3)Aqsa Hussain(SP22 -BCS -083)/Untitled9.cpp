 #include <iostream>
using namespace std;

int main() {
 class MyClass {
    public:
        int data;
        MyClass(int val) : data(val) {}
    };
    MyClass obj(42);
    MyClass* obj_ptr = &obj;
    cout << "\nProgram 12: Pointers to Objects" << endl;
    cout << "Value of obj.data: " << obj.data << endl;
    cout << "Value pointed to by obj_ptr->data: " << obj_ptr->data << endl;

   return 0;}
