#include <iostream>
using namespace std;

int main() {
 int v = 15;
    int* const const_ptr = &v;
    cout << "\nProgram 10: Constant Pointer" << endl;
    cout << "Value of v: " << v << endl;
    cout << "Value pointed to by const_ptr: " << *const_ptr << endl;
    return 0;}
