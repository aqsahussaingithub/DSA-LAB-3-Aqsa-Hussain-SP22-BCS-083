#include <iostream>
class MyClass {
public:
    int data = 42;
    void printData() {
        std::cout << "Data: " << data << std::endl;
    }
};

int main() {
    MyClass obj;
    int MyClass::*ptr = &MyClass::data;
    (obj.*ptr) = 84;
    obj.printData();
    return 0;
}

