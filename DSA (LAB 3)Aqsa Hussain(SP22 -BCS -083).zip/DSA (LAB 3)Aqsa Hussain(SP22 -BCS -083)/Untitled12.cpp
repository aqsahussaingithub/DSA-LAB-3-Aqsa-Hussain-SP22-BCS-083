#include <iostream>
using namespace std;

int main() {
 int arr15[] = {100, 200, 300};
    int* ptrArr[3];
    for (int i = 0; i < 3; i++) {
        ptrArr[i] = &arr15[i];
    }
    cout << "\nProgram 15: Pointer to Array of Pointers" << endl;
    for (int i = 0; i < 3; i++) {
        cout << "Value pointed to by ptrArr[" << i << "]: " << *ptrArr[i] << endl;
    }

    return 0;
}

void printValue(int* ptr) {
    cout << "Value pointed to by ptr: " << *ptr << endl;
}

int add(int a, int b) {
    return a + b;
}







