#include <iostream>
class Math {
public:
    int add(int a, int b) {
        return a + b;
    }
};

int main() {
    Math math;
    int (Math::*ptr)(int, int) = &Math::add;
    std::cout << "Sum: " << (math.*ptr)(3, 4) << std::endl;
    return 0;
}
