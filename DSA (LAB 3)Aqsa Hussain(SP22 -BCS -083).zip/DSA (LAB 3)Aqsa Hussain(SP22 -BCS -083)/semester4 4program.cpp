#include <iostream>
using namespace std;

int main() {
 int numbers[] = {1, 2, 3, 4, 5};
    int* arrPtr = numbers;
    cout << "\nProgram 4: Pointer to Array" << endl;
    for (int i = 0; i < 5; i++) {
        cout << "Value at arrPtr[" << i << "]: " << arrPtr[i] << endl;
    }
    return 0;}
