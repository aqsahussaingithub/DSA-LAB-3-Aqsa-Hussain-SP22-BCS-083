 #include <iostream>
using namespace std;

int main() {
 class MyStruct {
    public:
        int value;
    };
    MyStruct myStruct;
    int MyStruct::*memberPtr = &MyStruct::value;
    cout << "\nProgram 13: Pointer to Member Variable" << endl;
    myStruct.*memberPtr = 99;
    cout << "Value of myStruct.value: " << myStruct.value << endl;
return 0;}
