#include <iostream>
using namespace std;

int main() {
 const int z = 30;
    const int* constPtr = &z;
    cout << "\nProgram 8: Pointer to Constant" << endl;
    cout << "Value of z: " << z << endl;
    cout << "Value pointed to by constPtr: " << *constPtr << endl;
return 0;}
