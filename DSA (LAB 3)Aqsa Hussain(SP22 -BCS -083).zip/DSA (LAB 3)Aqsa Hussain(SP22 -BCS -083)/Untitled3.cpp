 #include <iostream>
using namespace std;

int main() {
 int* dynPtr = new int;
    *dynPtr = 42;
    cout << "\nProgram 3: Dynamic Memory Allocation" << endl;
    cout << "Value pointed to by dynPtr: " << *dynPtr << endl;
    delete dynPtr;
    return 0;}
