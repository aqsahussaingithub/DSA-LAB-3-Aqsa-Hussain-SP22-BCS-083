#include <iostream>
using namespace std;

int main() {
	 int const x1 = 100;
    int const *ptr_const = &x1;
    cout << "\nProgram 9: Pointer to Constant Data" << endl;
    cout << "Value of x1: " << x1 << endl;
    cout << "Value pointed to by ptr_const: " << *ptr_const << endl;
    return 0;}
