#include <iostream>
using namespace std;

int main() {
 int y = 20;
    int* ptr1 = &y;
    int** ptr2 = &ptr1;
    cout << "\nProgram 5: Pointer to Pointer" << endl;
    cout << "Value of y: " << y << endl;
    cout << "Value pointed to by ptr1: " << *ptr1 << endl;
    cout << "Value pointed to by ptr2 (ptr1): " << **ptr2 << endl;
return 0;}
