 #include <iostream>
using namespace std;

int main() {
 class MyClass2 {
    public:
        int add(int a, int b) { return a + b; }
    };
    int (MyClass2::*addPtr)(int, int) = &MyClass2::add;
    MyClass2 obj2;
    cout << "\nProgram 14: Pointer to Member Function" << endl;
    cout << "Result of obj2.add(3, 4) using addPtr: " << (obj2.*addPtr)(3, 4) << endl; 
    return 0;}
